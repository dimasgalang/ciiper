<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body id="page-top">
<!-- Page Wrapper -->
<div id="wrapper">
<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">
            <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-0 text-gray-800">Telegram Send Message</h1>
                </div>
                

                <!-- Approach -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Send Telegram Message</h6>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('telegram.send')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success alert-block">
                                <button type="button" class="close" data-dismiss="alert">×</button>	
                                <strong><?php echo e($message); ?></strong>
                            </div>
                            <?php endif; ?>

                            <?php if($message = Session::get('error')): ?>
                            <div class="alert alert-danger alert-block">
                                <button type="button" class="close" data-dismiss="alert">×</button>	
                                <strong><?php echo e($message); ?></strong>
                            </div>
                            <?php endif; ?>

                            <?php if($message = Session::get('warning')): ?>
                            <div class="alert alert-warning alert-block">
                                <button type="button" class="close" data-dismiss="alert">×</button>	
                                <strong><?php echo e($message); ?></strong>
                            </div>
                            <?php endif; ?>

                            <?php if($message = Session::get('info')): ?>
                            <div class="alert alert-info alert-block">
                                <button type="button" class="close" data-dismiss="alert">×</button>	
                                <strong><?php echo e($message); ?></strong>
                            </div>
                            <?php endif; ?>
                            <div>
                                <label>Telegram ID :</label>
                                <select class="form-control" id="chatid" multiple="multiple" name="chatid">
                                    <?php $__currentLoopData = $telegrams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $telegram): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($telegram->CHATID); ?>"><?php echo e($telegram->NAME); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <br>
                            <div>
                                <label>Text :</label>
                                <input class="form-control" type="text" id="message" name="message">
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary btn-block">SEND</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Content Row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<script type="text/javascript">
    $("#chatid").select2({
          allowClear: true
    });
</script>
</html><?php /**PATH C:\laragon\www\personalia\resources\views/telegram/index.blade.php ENDPATH**/ ?>