<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body id="page-top">
<!-- Page Wrapper -->
<div id="wrapper">
<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Begin Page Content -->
            <div class="container-fluid">
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>	
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>

                <?php if($message = Session::get('error')): ?>
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>	
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>

                <?php if($message = Session::get('warning')): ?>
                <div class="alert alert-warning alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>	
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>

                <?php if($message = Session::get('info')): ?>
                <div class="alert alert-info alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>	
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>
                
                <!-- Page Heading -->
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                    <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                            class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
                </div>

                <!-- Content Row -->
                <div class="row">
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            TOTAL PKWT</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($employee[0]->JUMLAH); ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-user fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            TOTAL INTERNSHIP</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($intern[0]->JUMLAH); ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-user fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            TOTAL PKWT + INTERNSHIP</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($employee[0]->JUMLAH + $intern[0]->JUMLAH); ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-users fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">PKWT RATIO
                                        </div>
                                        <div class="row no-gutters align-items-center">
                                            <div class="col-auto">
                                                <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?php echo e(number_format($employee[0]->JUMLAH/($employee[0]->JUMLAH + $intern[0]->JUMLAH)*100, 2, '.', ',')); ?>%</div>
                                            </div>
                                            <div class="col">
                                                <div class="progress progress-sm mr-2">
                                                    <div class="progress-bar bg-info" role="progressbar"
                                                        style="width: <?php echo e($employee[0]->JUMLAH/($employee[0]->JUMLAH + $intern[0]->JUMLAH)*100); ?>%" aria-valuenow="50" aria-valuemin="0"
                                                        aria-valuemax="100"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-tasks fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Approach -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Development Approach</h6>
                    </div>
                    <div class="card-body">
                        <p>CIIPER System is a personnel application of PT. Chutex International Indonesia.</p>
                    </div>
                </div>
                <div class="row">
                    <!-- Area Chart -->
                    <div class="col-xl-8 col-lg-7">
                        <div class="card shadow mb-4">
                            <!-- Card Header - Dropdown -->
                            <div
                                class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                <h6 class="m-0 font-weight-bold text-primary">EMPLOYEE CHART</h6>
                            </div>
                            <!-- Card Body -->
                            <div class="card-body">
                                <?php if (isset($component)) { $__componentOriginal6675c8df65c3da24f83d21e6b6c7d707 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6675c8df65c3da24f83d21e6b6c7d707 = $attributes; } ?>
<?php $component = IcehouseVentures\LaravelChartjs\View\Components\ChartjsComponent::resolve(['chart' => $chart] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('chartjs-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(IcehouseVentures\LaravelChartjs\View\Components\ChartjsComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6675c8df65c3da24f83d21e6b6c7d707)): ?>
<?php $attributes = $__attributesOriginal6675c8df65c3da24f83d21e6b6c7d707; ?>
<?php unset($__attributesOriginal6675c8df65c3da24f83d21e6b6c7d707); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6675c8df65c3da24f83d21e6b6c7d707)): ?>
<?php $component = $__componentOriginal6675c8df65c3da24f83d21e6b6c7d707; ?>
<?php unset($__componentOriginal6675c8df65c3da24f83d21e6b6c7d707); ?>
<?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Content Row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\laragon\www\personalia\resources\views/menu/home.blade.php ENDPATH**/ ?>